import pandas as pd
from flask import Flask, render_template, session, redirect, url_for, session
from flask_wtf import FlaskForm
from wtforms import (StringField, BooleanField, DateTimeField,
                     RadioField,SelectField,TextField,
                     TextAreaField,SubmitField, SelectMultipleField)
from wtforms.validators import DataRequired

df = pd.read_excel("salesfunnel.xlsx")
mgr_options = df["Manager"].unique()
rep_options = df["Rep"].unique()
pv = pd.pivot_table(df, index=['Name'], values=['Quantity'], aggfunc=sum, fill_value=0)
x=list(pv.index)
y=list(pv["Quantity"])
z=list(zip(x,y))

pass_list= list(zip(mgr_options,mgr_options))
pass_list2=list(zip(rep_options,rep_options))

app = Flask(__name__)
app.static_folder= '/Users/Abhishek/Documents/python/exl_dashboard/templates/static'
# Configure a secret SECRET_KEY
# We will later learn much better ways to do this!!
app.config['SECRET_KEY'] = 'mysecretkey'

# Now create a WTForm Class
# Lots of fields available:
# http://wtforms.readthedocs.io/en/stable/fields.html
class InfoForm(FlaskForm):
    '''
    This general class gets a lot of form about puppies.
    Mainly a way to go through many of the WTForms Fields.
    '''
    manager = SelectMultipleField(u'Things', choices=pass_list)
    rep = SelectMultipleField(u'Things', choices=pass_list2)
    submit = SubmitField('Submit')



@app.route('/', methods=['GET', 'POST'])
def index():
    if magic=='Debra Henley':
        df1=df[df["manager"]=='Debra Henley']
    elif magic2 in rep_options:
        df2=df1[df1["rep"].isin(magic2)]
    elif magic=='Fred Anderson':
        df1=df[df["manager"]=='Fred Anderson']
    elif magic2 in rep_options:
        df2=df1[df1["rep"].isin(magic2)]
    pv = pd.pivot_table(df2, index=['Name'], values=['Quantity'], aggfunc=sum, fill_value=0)
        x=list(pv.index)
        y=list(pv["Quantity"])
        z=list(zip(x,y))
        session['manager'] = magic
        session['rep']=magic2
        session["output"]=z
    form = InfoForm()
    if form.validate_on_submit():
        magic = form.manager.data
        magic2=form.rep.data
        return redirect(url_for("index"))
    return render_template('main.html', form=form)


if __name__ == '__main__':
    app.run(debug=True,port=5020)
