const

// Identifies HTML elements in the DOM that we will need
makesDropdown = document.getElementById("makesDropdown"),
modelsDropdown = document.getElementById("modelsDropdown"),

// Puts Makes and Models in a `cars` object for reference
cars = {Chevy: ["Camaro", "Corvette", "Impala"],
Dodge: ["Avenger", "Challenger", "Charger"],
Ford:  ["Mustang", "Shelby"]};

// Calls the appropriate function when a selection changes
makesDropdown.addEventListener("change", updateModelsDropdown);
modelsDropdown.addEventListener("change", updateMakesDropdown);


// Defines listener functions
function updateModelsDropdown(event){
let
// The "target" of the `change` event is the input that changed
thisMake = event.target.value,

// Gets the array of models from `cars` (If no make is selected, uses all models)
relevantModels = cars[thisMake] || getAllModels();
modelsDropdown.selectedIndex = 0; // Shows the first (blank) option

// The select element's children are the options
let optionElements = modelsDropdown.children;
for(let option of optionElements){

// Uses CSS to hide (or unhide) HTML elements
option.classList.add("hidden");

// Keeps the blank option as well as the ones included in the array
if(relevantModels.includes(option.value) || option.value === ""){
    option.classList.remove("hidden");
}
}
}

function updateMakesDropdown(event){
let
thisModel = event.target.value,
relevantMake = "",

// Gets an array of the "keys" for an object
allMakes = Object.keys(cars);

// Loops through the keys and tests each corresponding value (ie, each array of models)
for(let make of allMakes){
let models = cars[make];

// Finds the key whose value includes the selected model
if(models.includes(thisModel)){

    // Saves the name of the key so we can select it in the makesDropdown
    relevantMake = make;
}
}
let optionElements = makesDropdown.children;
for(let i = 0; i < optionElements.length; i++){

// Finds the index of the matching value
if(relevantMake === optionElements[i].value){

    // Selects the option by its index
    makesDropdown.selectedIndex = i;
}
}
}

// Defines a helper function
function getAllModels(){

// Gets an array of the "keys" for an object
const makes = Object.keys(cars);
const models = []; // Starts with an empty array to push models into
for(let make of makes){

// `cars[make]` retrieves the value (array of models) for that key
// `...` spreads the array into individual values (models)
// `push` adds each model to the new `models` array
models.push(...cars[make]);
}
return models;
}