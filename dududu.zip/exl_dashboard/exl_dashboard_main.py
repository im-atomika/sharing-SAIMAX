import pandas as pd
from flask import Flask, render_template, session, redirect, url_for, session
from flask_wtf import FlaskForm
from wtforms import (StringField, BooleanField, DateTimeField,
                     RadioField,SelectField,TextField,
                     TextAreaField,SubmitField, SelectMultipleField)
from wtforms.validators import DataRequired

df = pd.read_excel("salesfunnel.xlsx")
mgr_options = list(df["Manager"].unique())
rep_options = list(df["Rep"].unique())
pass_list= list(zip(mgr_options,mgr_options))
pass_list2=list(zip(rep_options,rep_options))

app = Flask(__name__)
app.static_folder= '/Users/Abhishek/Documents/python/exl_dashboard/templates/static'
# Configure a secret SECRET_KEY
# We will later learn much better ways to do this!!
app.config['SECRET_KEY'] = 'mysecretkey'

# Now create a WTForm Class
# Lots  fields available:
# http://wtforms.readthedocs.io/en/stable/fields.html
class InfoForm(FlaskForm):
    manager = SelectMultipleField(u'Things', choices=pass_list)
    rep = SelectMultipleField(u'Things2', choices=pass_list2)
    submit = SubmitField('Submit')



@app.route('/', methods=['GET', 'POST'])
def index():

    form = InfoForm()
    if form.validate_on_submit():
        manager_data = form.manager.data
        rep_data = form.rep.data
        if manager_data in mgr_options:
            df1=df[df["manager"].isin(manager_data)]
        if rep_data in rep_options:
            df2=df1[df1['rep'].isin(rep_data)]
        pv = pd.pivot_table(df, index=['Name'], values=['Quantity'], aggfunc=sum, fill_value=0)
        x=list(pv.index)
        y=list(pv["Quantity"])
        z=list(zip(x,y))
        session['manager'] = manager_data
        session['rep'] = rep_data
        session['output'] = z

        return redirect(url_for("index"))


    return render_template('main.html', form=form)


if __name__ == '__main__':
    app.run(debug=True)
