import pandas as pd
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField,SelectMultipleField,SelectField
from wtforms.validators import DataRequired,Email,EqualTo
from wtforms import ValidationError


df = pd.read_excel("salesfunnel.xlsx")
mgr_options = list(df["Manager"].unique())
rep_options = list(df["Rep"].unique())
pass_list= list(zip(mgr_options,mgr_options))
pass_list2=list(zip(rep_options,rep_options))

class PivotForm(FlaskForm):
    manager = SelectMultipleField(u'manager', choices=pass_list)
    rep = SelectMultipleField(u'rep', choices=pass_list2)
    submit = SubmitField('Submit')


class InfoForm(FlaskForm):
    manager = SelectMultipleField(u'manager', choices=pass_list)
    rep = SelectMultipleField(u'rep', choices=pass_list2)
    submit = SubmitField('Submit')

##########################################
############-Creative Form-#################
##########################################
class CreativeForm(FlaskForm):
    year01 = SelectMultipleField(u'data string1', choices=pass_list)
    creative01 = SelectMultipleField(u'data string2', choices=pass_list)
    submit = SubmitField('Submit')

class CreativeForm2(FlaskForm):
    year02 = SelectMultipleField(u'data string1', choices=pass_list2)
    creative02 = SelectMultipleField(u'data string2', choices=pass_list2)
    submit = SubmitField('Submit')


#########################################
#########################################

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Log In')

class RegistrationForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(),Email()])
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired(), EqualTo('pass_confirm', message='Passwords Must Match!')])
    pass_confirm = PasswordField('Confirm password', validators=[DataRequired()])
    client_nm = SelectField(u'client_nm', choices=[('None','Select Client'),('patelco','patelco'),('hearinglife','hearinglife')], default='None')
    user_rank = SelectField(u'user_rank', choices=[('None','Set user Rank'),('admin','Administrator'),('user','Normal User')], default='None')
    submit = SubmitField('Register!')

    def check_email(self, field):
        # Check if not None for that user email!
        if User.query.filter_by(email=field.data).first():
            raise ValidationError('Your email has been registered already!')

    def check_username(self, field):
        # Check if not None for that username!
        if User.query.filter_by(username=field.data).first():
            raise ValidationError('Sorry, that username is taken!')
