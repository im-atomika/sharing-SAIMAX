###############imports##########################
import pandas as pd
from dashboard_src import app,db
from flask import render_template, redirect, request, url_for, flash,abort, session
from flask_login import login_user,login_required,logout_user, current_user
from dashboard_src.models import User
from dashboard_src.forms import LoginForm, RegistrationForm, InfoForm, PivotForm
from werkzeug.security import generate_password_hash, check_password_hash


##############File_play##################
df = pd.read_excel("salesfunnel.xlsx")
mgr_options = list(df["Manager"].unique())
rep_options = list(df["Rep"].unique())
pass_list= list(zip(mgr_options,mgr_options))
pass_list2=list(zip(rep_options,rep_options))
######################Views################################
@app.route('/',methods=['GET','POST'])
def login():

    form = LoginForm()
    if form.validate_on_submit():

        user = User.query.filter_by(email=form.email.data).first()

        if user.check_password(form.password.data) and user is not None:


            login_user(user)
            flash('Logged in successfully.')
            next = request.args.get('next')
            if next == None or not next[0]=='/':
                next = url_for('dashboard')

            return redirect(next)
    return render_template('login.html', form=form)

@app.route('/register',methods=['GET','POST'])
def register():
        check = current_user.get_id()
        if  check in '1':

            form = RegistrationForm()

            if form.validate_on_submit():
                user = User(email=form.email.data,
                            username=form.username.data,
                            password=form.password.data)

                db.session.add(user)
                db.session.commit()
                flash('Thanks for registering! Now you can login!')
                return redirect(url_for('login'))
            return render_template('register.html', form=form)
        else:
            return redirect(url_for('login'))

#########incase of loosing data base ###################
########Uncomment this area & comment###################
#########the above given registration code##############
#    form = RegistrationForm()
#    if form.validate_on_submit():
#        user = User(email=form.email.data,
#                    username=form.username.data,
#                    password=form.password.data)

#        db.session.add(user)
#        db.session.commit()
#        flash('Thanks for registering! Now you can login!')
#        return redirect(url_for('login'))
#    return render_template('register.html', form=form)
#######################################################################
@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You logged out!')
    return redirect(url_for('login'))


@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():

    form = InfoForm()
    if form.validate_on_submit():
        manager_data = form.manager.data
        rep_data = form.rep.data
        if manager_data in mgr_options:
            df1=df[df["manager"].isin(manager_data)]
        if rep_data in rep_options:
            df2=df1[df1['rep'].isin(rep_data)]
        pv = pd.pivot_table(df, index=['Name'], values=['Quantity'], aggfunc=sum, fill_value=0)
        x=list(pv.index)
        y=list(pv["Quantity"])
        z=list(zip(x,y))
        session['manager'] = manager_data
        session['rep'] = rep_data
        session['output'] = z

        return redirect(url_for("dashboard"))


    return render_template('main.html', form=form)

@app.route('/pivot',methods=['GET','POST'])
@login_required
def pivot():
    pv = pd.pivot_table(df, index=['Name'], values=['Quantity'], aggfunc=sum, fill_value=0)
    pv.reset_index(inplace=True)
    ll=list(pv.columns)
    l1=list(pv.iloc[:,0])
    l2=list(pv.iloc[:,1])
    form = PivotForm()
    if form.validate_on_submit():
        session['pivot']=list(zip(l1,l2))
        return redirect(url_for("pivot"))

    return render_template('pivot.html',ll=ll,form=form)

##########################views#######################


if __name__ == '__main__':
    app.run(debug=True,port=80)
