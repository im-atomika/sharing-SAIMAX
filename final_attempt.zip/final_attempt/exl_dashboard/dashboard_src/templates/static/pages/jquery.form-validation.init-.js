/**
 * Theme: Amezia - Responsive Bootstrap 4 Admin Dashboard
 * Author: Themesbrand
 * Form Validation
 */


$(function () {
    $('form').parsley();
});


