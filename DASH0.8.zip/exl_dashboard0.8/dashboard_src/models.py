from dashboard_src  import db,login_manager
from werkzeug.security import generate_password_hash,check_password_hash
from flask_login import UserMixin

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(user_id)

class User(db.Model, UserMixin):

    # Create a table in the db
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key = True)
    email = db.Column(db.String(64), unique=True, index=True)
    username = db.Column(db.String(64), unique=True, index=True)
    client_nm = db.Column(db.String(64))
    user_rank = db.Column(db.String(64))
    password_hash = db.Column(db.String(128))

    def __init__(self, email, username, password, client_nm, user_rank):
        self.email = email
        self.username = username
        self.client_nm = client_nm
        self.user_rank = user_rank
        self.password_hash = generate_password_hash(password)

    def check_password(self,password):
        # https://stackoverflow.com/questions/23432478/flask-generate-password-hash-not-constant-output
        return check_password_hash(self.password_hash,password)
